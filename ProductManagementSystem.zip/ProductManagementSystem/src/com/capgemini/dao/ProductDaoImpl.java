package com.capgemini.dao;

import javax.persistence.EntityManager;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.util.DBUtil;

public class ProductDaoImpl implements IProductDao {

	private EntityManager entityManager;
	
	public ProductDaoImpl() {
		entityManager=DBUtil.getEntityManager();
	}
	
	
	@Override
	public int addProduct(Product product) throws ProductException {
		
		int productId=0;
		try{
		
			entityManager.getTransaction().begin();
			entityManager.persist(product);
			productId=product.getId();
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
	
		try{
			
			entityManager.getTransaction().begin();
			entityManager.merge(product);
			entityManager.flush();
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		Product product=null;
	try{
			
			entityManager.getTransaction().begin();
			product=entityManager.find(Product.class,id);
			entityManager.flush();
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		if(product==null)
		{
			throw new ProductException("No Product found with id="+id);
		}
	
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		try{
			
			entityManager.getTransaction().begin();
			Product product=entityManager.find(Product.class, id);
			entityManager.remove(product);
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}

	}

}
